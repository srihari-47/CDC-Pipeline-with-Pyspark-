#!/bin/bash

export SPARK_MASTER_HOST=ip-172-31-12-140.tail6d4ebc.ts.net 
export SPARK_WORKER_MEMORY=1g
export SPARK_WORKER_CORES=1
export SPARK_DRIVER_MEMORY=512m
export SPARK_DRIVER_CORES=1
export SPARK_DAEMON_MEMORY=256m
export SPARK_DRIVER_HOST=harisudhan-virtualbox.tail6d4ebc.ts.net
export SPARK_DRIVER_PORT=47100
export SPARK_LOG_DIR=/tmp/spark-logs

