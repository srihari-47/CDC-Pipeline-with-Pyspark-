class JobExecutionError(Exception):
    pass