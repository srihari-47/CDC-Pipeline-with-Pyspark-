TOPIC={'flights':'flight_server.public.flights',
         'customers':'flight_server.public.customers',
         'bookings':'flight_server.public.bookings'}
KAFKA_BOOTSTRAP_SERVER='harisudhan-virtualbox.tail6d4ebc.ts.net:9092'
SPARK_MASTER='local'
SPARK_MASTER_PROD='spark://ip-172-31-12-140.tail6d4ebc.ts.net:7077'
OUTPUT_PATH={'flights': 's3a://spark-hxs/flights/',
             'customers':'s3a://spark-hxs/customers/',
             'bookings':'s3a://spark-hxs/bookings/'}
CHECKPOINT_PATH={'flights':'s3a://spark-hxs/checkpoints/flights/',
             'customers':'s3a://spark-hxs/checkpoints/customers/',
             'bookings':'s3a://spark-hxs/checkpoints/bookings/'}
DEPLOY_MODE = 'client'
SPARK_APP_NAME = 'Spark_app'
SPARK_PACKAGE = ','.join(['org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.5',"org.apache.hadoop:hadoop-aws:3.3.4", "com.amazonaws:aws-java-sdk-bundle:1.12.262"])
TIMEZONE = 'UTC'
MAX_RETRY_ATTEMPTS = 3


